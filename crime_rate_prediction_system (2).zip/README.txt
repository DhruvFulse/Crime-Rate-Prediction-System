CRIME RATE PREDICTION & DATA MINING SYSTEM

Run:
1. Open a terminal in this folder (the one containing app.py).
2. pip install -r requirements.txt
3. streamlit run app.py

LOGIN
- Administrator (default account, created automatically on first run):
    username: admin        password: Admin@123
  Sign in on the "Administrator" tab. More admins can be added from Admin > Users.
- End users: open the "End user" tab, choose "Create account", then sign in.
- The two account types are separate: admin credentials do not work on the end-user
  tab and vice versa.

WHAT EACH ROLE SEES
Administrator
  Dashboard, Dataset (with CSV download), Preprocessing, Classification, Naive Bayes,
  Regression, Association Rules, Clustering, Comparison, Registered Crimes (view /
  download / delete), Users, Login History (download admin and end-user history as CSV)
End user
  Dashboard, Dataset (view only), Risk Check (predicts risk level and crime rate),
  Register Crime, My Reports (with status tracking)

REGISTERING A CRIME
End users fill in the incident and the area indicators. The system's decision tree and
regression model (trained on the original data) assign the Risk_Level and Crime_Rate, and the
record is stored in the database. The dataset, dashboard, every model and the comparison
read the combined data, so they update immediately. Records appear in the dataset with
Source = "User report" and IDs starting with U.

REPORT STATUS TRACKING
Every registered crime starts as "Registered". Administrators move it forward from
Registered Crimes > Update report status, with an optional remark:
    Registered > Under Review > Under Investigation > Resolved > Closed
The user sees the status straight after registering (with a progress tracker and a
reference number), and can follow every change, with time, updater and remarks, under
My Reports > Track a report. Databases from the earlier version are upgraded automatically.

COMPARISON MODULE
- Classification: Decision Tree vs Naive Bayes
- Regression:     Linear Regression vs Decision Tree Regressor vs Random Forest Regressor
- Clustering:     K-Means vs Gaussian Mixture vs Agglomerative (Ward)
- Association rules: Apriori (descriptive, not ranked)
Each family gets its own metric table, charts, winner and explanation, followed by a final
recommendation for the whole system.

FILES
- app.py        the Streamlit website
- db.py         SQLite database: accounts (salted PBKDF2 password hashes), login history,
                user-registered crimes. crime_system.db is created on first run.
- dataset.py    generates the 10,000-row dataset (python dataset.py also writes the CSV)
- crime_data_10000.csv  the original generated dataset
- .streamlit/config.toml  theme colours

To reset everything (accounts, history, registered crimes), stop the app and delete
crime_system.db.
